# Splunker cli (demucs)

little cli thingy, beta, horrible code, yada yada etc etc
kill me
